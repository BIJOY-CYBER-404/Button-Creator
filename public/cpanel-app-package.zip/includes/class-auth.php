<?php
/**
 * Authentication and Admin Session Protection with MySQL Database
 */

if (basename($_SERVER['SCRIPT_FILENAME'] ?? '') === basename(__FILE__)) {
    http_response_code(403);
    exit('Forbidden');
}

require_once __DIR__ . '/class-db.php';

class SLEA_Auth {
    public static function start_session() {
        @header_remove('X-Powered-By');
        if (session_status() === PHP_SESSION_NONE) {
            @ini_set('session.cookie_httponly', '1');
            @ini_set('session.use_only_cookies', '1');
            @ini_set('session.use_strict_mode', '1');
            @ini_set('session.cookie_samesite', 'Lax');
            @ini_set('session.cookie_path', '/');
            if (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') {
                @ini_set('session.cookie_secure', '1');
            }
            session_start();
        }
    }

    public static function is_rate_limited() {
        self::start_session();
        $attempts = $_SESSION['slea_login_attempts'] ?? 0;
        $lock_until = $_SESSION['slea_login_lock_until'] ?? 0;
        if ($lock_until > time()) {
            return true;
        }
        if ($lock_until > 0 && $lock_until <= time()) {
            $_SESSION['slea_login_attempts'] = 0;
            $_SESSION['slea_login_lock_until'] = 0;
        }
        return $attempts >= 5;
    }

    public static function has_users() {
        try {
            $pdo = SLEA_DB::get_connection();
            $stmt = $pdo->query("SELECT COUNT(*) AS total FROM users");
            $row = $stmt->fetch();
            $has = !empty($row) && intval($row['total']) > 0;
            if ($has) {
                self::sync_users_backup();
            }
            return $has;
        } catch (Exception $e) {
            return false;
        }
    }

    public static function sync_users_backup() {
        try {
            $pdo = SLEA_DB::get_connection();
            $stmt = $pdo->query("SELECT id, username, email, password_hash, role, permissions, created_at, updated_at FROM users ORDER BY id ASC");
            $rows = $stmt ? $stmt->fetchAll(PDO::FETCH_ASSOC) : [];
            if (!empty($rows)) {
                $data_dir = defined('DATA_DIR') ? DATA_DIR : (APP_ROOT . '/data');
                if (!is_dir($data_dir)) {
                    @mkdir($data_dir, 0755, true);
                }
                @file_put_contents($data_dir . '/users_backup.json', json_encode($rows, JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
            }
        } catch (Exception $e) {
            // non-blocking
        }
    }

    public static function is_logged_in() {
        self::start_session();
        return !empty($_SESSION['slea_admin_logged_in']) && $_SESSION['slea_admin_logged_in'] === true;
    }

    public static function get_current_user() {
        self::start_session();
        if (!self::is_logged_in()) {
            return null;
        }
        return [
            'id'          => $_SESSION['slea_admin_id'] ?? 0,
            'username'    => $_SESSION['slea_admin_user'] ?? 'admin',
            'email'       => $_SESSION['slea_admin_email'] ?? '',
            'role'        => $_SESSION['slea_admin_role'] ?? 'admin',
            'permissions' => $_SESSION['slea_admin_perms'] ?? ['all']
        ];
    }

    /**
     * One-time account creation for the initial administrator.
     * Permanently locked once an admin account exists!
     */
    public static function create_first_admin($username, $email, $password) {
        if (self::has_users()) {
            return [
                'success' => false,
                'error'   => 'Setup has already been completed. Account creation is permanently closed.'
            ];
        }

        $username = trim($username);
        $email    = trim($email);
        $password = trim($password);

        if (strlen($username) < 3) {
            return ['success' => false, 'error' => 'Username must be at least 3 characters.'];
        }
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            return ['success' => false, 'error' => 'Please provide a valid email address.'];
        }
        if (strlen($password) < 6) {
            return ['success' => false, 'error' => 'Password must be at least 6 characters long.'];
        }

        try {
            $pdo = SLEA_DB::get_connection();
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $now  = date('Y-m-d H:i:s');
            $perms = json_encode(['all', 'pages', 'settings', 'generator', 'users']);

            $stmt = $pdo->prepare("
                INSERT INTO users (username, email, password_hash, role, permissions, created_at, updated_at)
                VALUES (:u, :e, :p, 'superadmin', :perms, :created_at, :updated_at)
            ");
            $stmt->execute([
                ':u'          => $username,
                ':e'          => $email,
                ':p'          => $hash,
                ':perms'      => $perms,
                ':created_at' => $now,
                ':updated_at' => $now
            ]);

            $id = $pdo->lastInsertId();
            self::sync_users_backup();

            // Automatically log in
            self::start_session();
            @session_regenerate_id(true);
            $_SESSION['slea_admin_logged_in'] = true;
            $_SESSION['slea_admin_id']        = $id;
            $_SESSION['slea_admin_user']      = $username;
            $_SESSION['slea_admin_email']     = $email;
            $_SESSION['slea_admin_role']      = 'superadmin';
            $_SESSION['slea_admin_perms']     = ['all'];

            return ['success' => true];
        } catch (Exception $e) {
            error_log('Account setup error: ' . $e->getMessage());
            return ['success' => false, 'error' => 'Unable to complete account setup. Please try again.'];
        }
    }

    public static function login($username_or_email, $password) {
        self::start_session();
        if (self::is_rate_limited()) {
            return false;
        }
        $input = trim($username_or_email);

        try {
            $pdo = SLEA_DB::get_connection();
            $stmt = $pdo->prepare("SELECT * FROM users WHERE username = :uname OR email = :uemail LIMIT 1");
            $stmt->execute([
                ':uname'  => $input,
                ':uemail' => $input
            ]);
            $user = $stmt->fetch();

            if ($user && password_verify($password, $user['password_hash'])) {
                @session_regenerate_id(true);
                $_SESSION['slea_login_attempts']  = 0;
                $_SESSION['slea_login_lock_until']= 0;
                $_SESSION['slea_admin_logged_in'] = true;
                $_SESSION['slea_admin_id']        = $user['id'];
                $_SESSION['slea_admin_user']      = $user['username'];
                $_SESSION['slea_admin_email']     = $user['email'];
                $_SESSION['slea_admin_role']      = $user['role'];
                $_SESSION['slea_admin_perms']     = !empty($user['permissions']) ? json_decode($user['permissions'], true) : ['all'];
                $_SESSION['slea_login_time']      = time();
                return true;
            }
        } catch (Exception $e) {
            error_log('Login error: ' . $e->getMessage());
        }

        $_SESSION['slea_login_attempts'] = ($_SESSION['slea_login_attempts'] ?? 0) + 1;
        if ($_SESSION['slea_login_attempts'] >= 5) {
            $_SESSION['slea_login_lock_until'] = time() + 600;
        }

        return false;
    }

    public static function logout() {
        self::start_session();
        $_SESSION = [];
        if (ini_get("session.use_cookies")) {
            $params = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000,
                $params["path"], $params["domain"],
                $params["secure"], $params["httponly"]
            );
        }
        session_destroy();
    }

    public static function render_404($title = '404 Not Found', $message = 'The requested page does not exist or has been removed.') {
        header('X-Robots-Tag: noindex, nofollow, noarchive, nosnippet');
        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Pragma: no-cache');
        header('Expires: 0');
        header('X-LiteSpeed-Cache-Control: no-cache');
        http_response_code(404);
        ?>
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <meta name="robots" content="noindex, nofollow">
            <title><?= htmlspecialchars($title) ?></title>
            <style>
                body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; background: #f8fafd; color: #1f1f1f; text-align: center; padding: 60px 20px; margin: 0; }
                .box { max-width: 440px; margin: 0 auto; background: #ffffff; padding: 32px; border-radius: 24px; border: 1px solid #e0e4eb; box-shadow: 0 1px 2px rgba(0,0,0,0.05); }
                h1 { color: #d93025; font-size: 20px; margin-top: 0; margin-bottom: 8px; }
                p { font-size: 13px; color: #5f6368; margin: 0; }
            </style>
        </head>
        <body>
            <div class="box">
                <h1><?= htmlspecialchars($title) ?></h1>
                <p><?= htmlspecialchars($message) ?></p>
            </div>
        </body>
        </html>
        <?php
        exit;
    }

    public static function require_admin() {
        self::start_session();
        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Pragma: no-cache');
        header('Expires: 0');
        header('X-LiteSpeed-Cache-Control: no-cache');
        if (!self::is_logged_in()) {
            if ((isset($_SERVER['HTTP_ACCEPT']) && strpos($_SERVER['HTTP_ACCEPT'], 'application/json') !== false)
                || (isset($_SERVER['CONTENT_TYPE']) && strpos($_SERVER['CONTENT_TYPE'], 'application/json') !== false)
                || (isset($_SERVER['REQUEST_URI']) && stripos($_SERVER['REQUEST_URI'], 'api.php') !== false)) {
                header('Content-Type: application/json; charset=utf-8');
                http_response_code(404);
                echo json_encode([
                    'success' => false,
                    'error'   => '404 Not Found'
                ]);
                exit;
            }
            // Show 404 instead of redirecting to login page when not logged in as admin
            self::render_404();
        }
    }
}
